/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "E:/1. work/digital program/work3/add16.vhd";
extern char *IEEE_P_2592010699;

unsigned char ieee_p_2592010699_sub_1605435078_503743352(char *, unsigned char , unsigned char );
unsigned char ieee_p_2592010699_sub_2507238156_503743352(char *, unsigned char , unsigned char );
unsigned char ieee_p_2592010699_sub_2545490612_503743352(char *, unsigned char , unsigned char );


static void work_a_3971542341_3212880686_p_0(char *t0)
{
    char *t1;
    char *t2;
    int t3;
    unsigned int t4;
    unsigned int t5;
    unsigned int t6;
    int t7;
    char *t8;
    char *t9;
    int t10;
    int t11;
    char *t12;
    unsigned char t13;
    char *t14;
    char *t15;
    int t16;
    int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    char *t21;
    unsigned char t22;
    unsigned char t23;
    char *t24;
    char *t25;
    int t26;
    int t27;
    unsigned int t28;
    unsigned int t29;
    unsigned int t30;
    char *t31;
    unsigned char t32;
    unsigned char t33;
    char *t34;
    char *t35;
    int t36;
    int t37;
    unsigned int t38;
    unsigned int t39;
    unsigned int t40;
    char *t41;
    unsigned char t42;
    unsigned char t43;
    int t44;
    int t45;
    unsigned int t46;
    unsigned int t47;
    unsigned int t48;
    char *t49;
    unsigned char t50;
    char *t51;
    char *t52;
    int t53;
    int t54;
    unsigned int t55;
    unsigned int t56;
    unsigned int t57;
    char *t58;
    unsigned char t59;
    unsigned char t60;
    unsigned char t61;
    char *t62;
    char *t63;
    int t64;
    int t65;
    int t66;
    unsigned int t67;
    unsigned int t68;
    unsigned int t69;
    char *t70;

LAB0:    xsi_set_current_line(34, ng0);
    t1 = (t0 + 1648U);
    t2 = *((char **)t1);
    t3 = (0 - 16);
    t4 = (t3 * -1);
    t5 = (1U * t4);
    t6 = (0 + t5);
    t1 = (t2 + t6);
    *((unsigned char *)t1) = (unsigned char)2;
    xsi_set_current_line(35, ng0);
    t1 = (t0 + 4917);
    *((int *)t1) = 0;
    t2 = (t0 + 4921);
    *((int *)t2) = 15;
    t3 = 0;
    t7 = 15;

LAB2:    if (t3 <= t7)
        goto LAB3;

LAB5:    xsi_set_current_line(39, ng0);
    t1 = (t0 + 1768U);
    t2 = *((char **)t1);
    t1 = (t0 + 3152);
    t8 = (t1 + 56U);
    t9 = *((char **)t8);
    t12 = (t9 + 56U);
    t14 = *((char **)t12);
    memcpy(t14, t2, 16U);
    xsi_driver_first_trans_fast_port(t1);
    t1 = (t0 + 3072);
    *((int *)t1) = 1;

LAB1:    return;
LAB3:    xsi_set_current_line(36, ng0);
    t8 = (t0 + 1032U);
    t9 = *((char **)t8);
    t8 = (t0 + 4917);
    t10 = *((int *)t8);
    t11 = (t10 - 15);
    t4 = (t11 * -1);
    xsi_vhdl_check_range_of_index(15, 0, -1, *((int *)t8));
    t5 = (1U * t4);
    t6 = (0 + t5);
    t12 = (t9 + t6);
    t13 = *((unsigned char *)t12);
    t14 = (t0 + 1192U);
    t15 = *((char **)t14);
    t14 = (t0 + 4917);
    t16 = *((int *)t14);
    t17 = (t16 - 15);
    t18 = (t17 * -1);
    xsi_vhdl_check_range_of_index(15, 0, -1, *((int *)t14));
    t19 = (1U * t18);
    t20 = (0 + t19);
    t21 = (t15 + t20);
    t22 = *((unsigned char *)t21);
    t23 = ieee_p_2592010699_sub_2507238156_503743352(IEEE_P_2592010699, t13, t22);
    t24 = (t0 + 1648U);
    t25 = *((char **)t24);
    t24 = (t0 + 4917);
    t26 = *((int *)t24);
    t27 = (t26 - 16);
    t28 = (t27 * -1);
    xsi_vhdl_check_range_of_index(16, 0, -1, *((int *)t24));
    t29 = (1U * t28);
    t30 = (0 + t29);
    t31 = (t25 + t30);
    t32 = *((unsigned char *)t31);
    t33 = ieee_p_2592010699_sub_2507238156_503743352(IEEE_P_2592010699, t23, t32);
    t34 = (t0 + 1768U);
    t35 = *((char **)t34);
    t34 = (t0 + 4917);
    t36 = *((int *)t34);
    t37 = (t36 - 15);
    t38 = (t37 * -1);
    xsi_vhdl_check_range_of_index(15, 0, -1, *((int *)t34));
    t39 = (1U * t38);
    t40 = (0 + t39);
    t41 = (t35 + t40);
    *((unsigned char *)t41) = t33;
    xsi_set_current_line(37, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 4917);
    t10 = *((int *)t1);
    t11 = (t10 - 15);
    t4 = (t11 * -1);
    xsi_vhdl_check_range_of_index(15, 0, -1, *((int *)t1));
    t5 = (1U * t4);
    t6 = (0 + t5);
    t8 = (t2 + t6);
    t13 = *((unsigned char *)t8);
    t9 = (t0 + 1648U);
    t12 = *((char **)t9);
    t9 = (t0 + 4917);
    t16 = *((int *)t9);
    t17 = (t16 - 16);
    t18 = (t17 * -1);
    xsi_vhdl_check_range_of_index(16, 0, -1, *((int *)t9));
    t19 = (1U * t18);
    t20 = (0 + t19);
    t14 = (t12 + t20);
    t22 = *((unsigned char *)t14);
    t23 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t13, t22);
    t15 = (t0 + 1032U);
    t21 = *((char **)t15);
    t15 = (t0 + 4917);
    t26 = *((int *)t15);
    t27 = (t26 - 15);
    t28 = (t27 * -1);
    xsi_vhdl_check_range_of_index(15, 0, -1, *((int *)t15));
    t29 = (1U * t28);
    t30 = (0 + t29);
    t24 = (t21 + t30);
    t32 = *((unsigned char *)t24);
    t25 = (t0 + 1192U);
    t31 = *((char **)t25);
    t25 = (t0 + 4917);
    t36 = *((int *)t25);
    t37 = (t36 - 15);
    t38 = (t37 * -1);
    xsi_vhdl_check_range_of_index(15, 0, -1, *((int *)t25));
    t39 = (1U * t38);
    t40 = (0 + t39);
    t34 = (t31 + t40);
    t33 = *((unsigned char *)t34);
    t42 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t32, t33);
    t43 = ieee_p_2592010699_sub_2545490612_503743352(IEEE_P_2592010699, t23, t42);
    t35 = (t0 + 1192U);
    t41 = *((char **)t35);
    t35 = (t0 + 4917);
    t44 = *((int *)t35);
    t45 = (t44 - 15);
    t46 = (t45 * -1);
    xsi_vhdl_check_range_of_index(15, 0, -1, *((int *)t35));
    t47 = (1U * t46);
    t48 = (0 + t47);
    t49 = (t41 + t48);
    t50 = *((unsigned char *)t49);
    t51 = (t0 + 1648U);
    t52 = *((char **)t51);
    t51 = (t0 + 4917);
    t53 = *((int *)t51);
    t54 = (t53 - 16);
    t55 = (t54 * -1);
    xsi_vhdl_check_range_of_index(16, 0, -1, *((int *)t51));
    t56 = (1U * t55);
    t57 = (0 + t56);
    t58 = (t52 + t57);
    t59 = *((unsigned char *)t58);
    t60 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t50, t59);
    t61 = ieee_p_2592010699_sub_2545490612_503743352(IEEE_P_2592010699, t43, t60);
    t62 = (t0 + 1648U);
    t63 = *((char **)t62);
    t62 = (t0 + 4917);
    t64 = *((int *)t62);
    t65 = (t64 + 1);
    t66 = (t65 - 16);
    t67 = (t66 * -1);
    xsi_vhdl_check_range_of_index(16, 0, -1, t65);
    t68 = (1U * t67);
    t69 = (0 + t68);
    t70 = (t63 + t69);
    *((unsigned char *)t70) = t61;

LAB4:    t1 = (t0 + 4917);
    t3 = *((int *)t1);
    t2 = (t0 + 4921);
    t7 = *((int *)t2);
    if (t3 == t7)
        goto LAB5;

LAB6:    t10 = (t3 + 1);
    t3 = t10;
    t8 = (t0 + 4917);
    *((int *)t8) = t3;
    goto LAB2;

}


extern void work_a_3971542341_3212880686_init()
{
	static char *pe[] = {(void *)work_a_3971542341_3212880686_p_0};
	xsi_register_didat("work_a_3971542341_3212880686", "isim/aadder_isim_beh.exe.sim/work/a_3971542341_3212880686.didat");
	xsi_register_executes(pe);
}
