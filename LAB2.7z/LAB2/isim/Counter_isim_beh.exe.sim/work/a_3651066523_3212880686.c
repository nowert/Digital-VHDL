/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "E:/1. work/digital program/LAB2/DFF7474X4.vhd";
extern char *IEEE_P_2592010699;

char *ieee_p_2592010699_sub_1837678034_503743352(char *, char *, char *, char *);


static void work_a_3651066523_3212880686_p_0(char *t0)
{
    char t21[16];
    unsigned char t1;
    char *t2;
    char *t3;
    unsigned char t4;
    unsigned char t5;
    char *t6;
    unsigned char t7;
    unsigned char t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    unsigned char t15;
    unsigned char t16;
    unsigned char t17;
    unsigned char t18;
    unsigned char t19;
    char *t20;
    unsigned int t22;
    unsigned int t23;

LAB0:    xsi_set_current_line(18, ng0);
    t2 = (t0 + 1352U);
    t3 = *((char **)t2);
    t4 = *((unsigned char *)t3);
    t5 = (t4 == (unsigned char)2);
    if (t5 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB2;

LAB4:    xsi_set_current_line(21, ng0);
    t2 = (t0 + 1352U);
    t3 = *((char **)t2);
    t4 = *((unsigned char *)t3);
    t5 = (t4 == (unsigned char)3);
    if (t5 == 1)
        goto LAB11;

LAB12:    t1 = (unsigned char)0;

LAB13:    if (t1 != 0)
        goto LAB8;

LAB10:    xsi_set_current_line(25, ng0);
    t2 = (t0 + 1352U);
    t3 = *((char **)t2);
    t5 = *((unsigned char *)t3);
    t7 = (t5 == (unsigned char)3);
    if (t7 == 1)
        goto LAB20;

LAB21:    t4 = (unsigned char)0;

LAB22:    if (t4 == 1)
        goto LAB17;

LAB18:    t1 = (unsigned char)0;

LAB19:    if (t1 != 0)
        goto LAB14;

LAB16:
LAB15:
LAB9:
LAB3:    t2 = (t0 + 3312);
    *((int *)t2) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(19, ng0);
    t2 = (t0 + 5255);
    t10 = (t0 + 3392);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    t13 = (t12 + 56U);
    t14 = *((char **)t13);
    memcpy(t14, t2, 4U);
    xsi_driver_first_trans_fast_port(t10);
    xsi_set_current_line(20, ng0);
    t2 = (t0 + 5259);
    t6 = (t0 + 3456);
    t9 = (t6 + 56U);
    t10 = *((char **)t9);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    memcpy(t12, t2, 4U);
    xsi_driver_first_trans_fast_port(t6);
    goto LAB3;

LAB5:    t2 = (t0 + 1512U);
    t6 = *((char **)t2);
    t7 = *((unsigned char *)t6);
    t8 = (t7 == (unsigned char)3);
    t1 = t8;
    goto LAB7;

LAB8:    xsi_set_current_line(22, ng0);
    t2 = (t0 + 5263);
    t10 = (t0 + 3392);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    t13 = (t12 + 56U);
    t14 = *((char **)t13);
    memcpy(t14, t2, 4U);
    xsi_driver_first_trans_fast_port(t10);
    xsi_set_current_line(23, ng0);
    t2 = (t0 + 5267);
    t6 = (t0 + 3456);
    t9 = (t6 + 56U);
    t10 = *((char **)t9);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    memcpy(t12, t2, 4U);
    xsi_driver_first_trans_fast_port(t6);
    goto LAB9;

LAB11:    t2 = (t0 + 1512U);
    t6 = *((char **)t2);
    t7 = *((unsigned char *)t6);
    t8 = (t7 == (unsigned char)2);
    t1 = t8;
    goto LAB13;

LAB14:    xsi_set_current_line(26, ng0);
    t9 = (t0 + 1032U);
    t11 = *((char **)t9);
    t9 = (t0 + 3392);
    t12 = (t9 + 56U);
    t13 = *((char **)t12);
    t14 = (t13 + 56U);
    t20 = *((char **)t14);
    memcpy(t20, t11, 4U);
    xsi_driver_first_trans_fast_port(t9);
    xsi_set_current_line(27, ng0);
    t2 = (t0 + 1032U);
    t3 = *((char **)t2);
    t2 = (t0 + 5184U);
    t6 = ieee_p_2592010699_sub_1837678034_503743352(IEEE_P_2592010699, t21, t3, t2);
    t9 = (t21 + 12U);
    t22 = *((unsigned int *)t9);
    t23 = (1U * t22);
    t1 = (4U != t23);
    if (t1 == 1)
        goto LAB26;

LAB27:    t10 = (t0 + 3456);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    t13 = (t12 + 56U);
    t14 = *((char **)t13);
    memcpy(t14, t6, 4U);
    xsi_driver_first_trans_fast_port(t10);
    goto LAB15;

LAB17:    t2 = (t0 + 1152U);
    t17 = xsi_signal_has_event(t2);
    if (t17 == 1)
        goto LAB23;

LAB24:    t16 = (unsigned char)0;

LAB25:    t1 = t16;
    goto LAB19;

LAB20:    t2 = (t0 + 1512U);
    t6 = *((char **)t2);
    t8 = *((unsigned char *)t6);
    t15 = (t8 == (unsigned char)3);
    t4 = t15;
    goto LAB22;

LAB23:    t9 = (t0 + 1192U);
    t10 = *((char **)t9);
    t18 = *((unsigned char *)t10);
    t19 = (t18 == (unsigned char)3);
    t16 = t19;
    goto LAB25;

LAB26:    xsi_size_not_matching(4U, t23, 0);
    goto LAB27;

}


extern void work_a_3651066523_3212880686_init()
{
	static char *pe[] = {(void *)work_a_3651066523_3212880686_p_0};
	xsi_register_didat("work_a_3651066523_3212880686", "isim/Counter_isim_beh.exe.sim/work/a_3651066523_3212880686.didat");
	xsi_register_executes(pe);
}
