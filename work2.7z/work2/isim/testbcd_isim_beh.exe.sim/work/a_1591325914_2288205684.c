/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "E:/1. work/digital program/work2/test2.vhd";
extern char *IEEE_P_2592010699;
extern char *IEEE_P_3620187407;

unsigned char ieee_p_2592010699_sub_1744673427_503743352(char *, char *, unsigned int , unsigned int );
char *ieee_p_3620187407_sub_436279890_3965413181(char *, char *, char *, char *, int );


static void work_a_1591325914_2288205684_p_0(char *t0)
{
    char t8[16];
    char *t1;
    char *t2;
    unsigned char t3;
    unsigned char t4;
    char *t5;
    char *t6;
    char *t7;
    char *t9;
    char *t10;
    unsigned int t11;
    unsigned int t12;
    int t13;
    char *t14;
    char *t15;

LAB0:    xsi_set_current_line(21, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t4 = (t3 == (unsigned char)3);
    if (t4 != 0)
        goto LAB2;

LAB4:    t1 = (t0 + 1152U);
    t3 = ieee_p_2592010699_sub_1744673427_503743352(IEEE_P_2592010699, t1, 0U, 0U);
    if (t3 != 0)
        goto LAB5;

LAB6:
LAB3:    xsi_set_current_line(26, ng0);
    t1 = (t0 + 1648U);
    t2 = *((char **)t1);
    t1 = (t0 + 4688U);
    t5 = (t0 + 4722);
    t7 = (t8 + 0U);
    t9 = (t7 + 0U);
    *((int *)t9) = 0;
    t9 = (t7 + 4U);
    *((int *)t9) = 3;
    t9 = (t7 + 8U);
    *((int *)t9) = 1;
    t13 = (3 - 0);
    t11 = (t13 * 1);
    t11 = (t11 + 1);
    t9 = (t7 + 12U);
    *((unsigned int *)t9) = t11;
    t3 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t2, t1, t5, t8);
    if (t3 != 0)
        goto LAB7;

LAB9:
LAB8:    xsi_set_current_line(29, ng0);
    t1 = (t0 + 1648U);
    t2 = *((char **)t1);
    t1 = (t0 + 3032);
    t5 = (t1 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t9 = *((char **)t7);
    memcpy(t9, t2, 4U);
    xsi_driver_first_trans_fast_port(t1);
    t1 = (t0 + 2952);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(22, ng0);
    t1 = (t0 + 4718);
    t6 = (t0 + 1648U);
    t7 = *((char **)t6);
    t6 = (t7 + 0);
    memcpy(t6, t1, 4U);
    goto LAB3;

LAB5:    xsi_set_current_line(24, ng0);
    t2 = (t0 + 1648U);
    t5 = *((char **)t2);
    t2 = (t0 + 4688U);
    t6 = ieee_p_3620187407_sub_436279890_3965413181(IEEE_P_3620187407, t8, t5, t2, 1);
    t7 = (t0 + 1648U);
    t9 = *((char **)t7);
    t7 = (t9 + 0);
    t10 = (t8 + 12U);
    t11 = *((unsigned int *)t10);
    t12 = (1U * t11);
    memcpy(t7, t6, t12);
    goto LAB3;

LAB7:    xsi_set_current_line(27, ng0);
    t9 = (t0 + 4726);
    t14 = (t0 + 1648U);
    t15 = *((char **)t14);
    t14 = (t15 + 0);
    memcpy(t14, t9, 4U);
    goto LAB8;

}


extern void work_a_1591325914_2288205684_init()
{
	static char *pe[] = {(void *)work_a_1591325914_2288205684_p_0};
	xsi_register_didat("work_a_1591325914_2288205684", "isim/testbcd_isim_beh.exe.sim/work/a_1591325914_2288205684.didat");
	xsi_register_executes(pe);
}
